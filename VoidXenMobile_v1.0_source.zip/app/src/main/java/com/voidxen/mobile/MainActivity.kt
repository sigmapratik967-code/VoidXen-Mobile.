package com.voidxen.mobile

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val ComponentActivity.dataStore by preferencesDataStore(name = "voidxen_settings")
private val CRIMSON = Color(0xFFE32645)
private val BG = Color(0xFF09090D)
private val PANEL = Color(0xFF17171F)
private val MUTED = Color(0xFFAAAAB5)

data class GameApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = CRIMSON, background = BG, surface = PANEL,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) {
                VoidXenApp(
                    loadSettings = {
                        val p = dataStore.data.first()
                        Triple(
                            p[stringPreferencesKey("launcher_title")] ?: "VoidXen Mobile",
                            p[stringPreferencesKey("server_ip")] ?: "188.127.241.74",
                            p[stringPreferencesKey("server_port")] ?: "1618"
                        )
                    },
                    saveSettings = { title, ip, port ->
                        dataStore.edit {
                            it[stringPreferencesKey("launcher_title")] = title
                            it[stringPreferencesKey("server_ip")] = ip
                            it[stringPreferencesKey("server_port")] = port
                        }
                    },
                    games = getInstalledGames(),
                    launchGame = { pkg ->
                        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
                    }
                )
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun getInstalledGames(): List<GameApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            packageManager.queryIntentActivities(intent, 0)
        }
        val ownPackage = packageName
        return results.mapNotNull {
            val pkg = it.activityInfo.packageName
            if (pkg == ownPackage) null else GameApp(
                it.loadLabel(packageManager).toString(), pkg
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }
}

@Composable
fun VoidXenApp(
    loadSettings: suspend () -> Triple<String, String, String>,
    saveSettings: suspend (String, String, String) -> Unit,
    games: List<GameApp>,
    launchGame: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("VoidXen Mobile") }
    var ip by remember { mutableStateOf("188.127.241.74") }
    var port by remember { mutableStateOf("1618") }
    var tab by remember { mutableStateOf(0) }
    var search by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val s = loadSettings()
        title = s.first; ip = s.second; port = s.third
    }

    Scaffold(containerColor = BG, bottomBar = {
        NavigationBar(containerColor = PANEL, contentColor = Color.White) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("Games") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(BG).padding(padding).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(CRIMSON, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Text("V", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("YOUR GAME. YOUR WORLD.", color = CRIMSON, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(24.dp))
            when (tab) {
                0 -> {
                    Text("WELCOME BACK", color = Color.LightGray, fontSize = 12.sp)
                    Text("Ready to play?", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(18.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("YOUR SERVER", color = Color.LightGray, fontSize = 11.sp)
                            Text("$ip:$port", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Server address saved in Settings", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("QUICK ACCESS", color = CRIMSON, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { tab = 1 }, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = CRIMSON)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("OPEN GAME LIBRARY")
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Installed apps detected: ${games.size}", color = Color.LightGray)
                    Text("Google sign-in will be enabled after Firebase setup.", color = Color.Gray, fontSize = 11.sp)
                }
                1 -> {
                    Text("GAME LIBRARY", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${games.size} launchable apps found", color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Search apps") }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(games.filter { it.label.contains(search, true) }) { game ->
                            Card(colors = CardDefaults.cardColors(containerColor = PANEL),
                                modifier = Modifier.fillMaxWidth().clickable { launchGame(game.packageName) }) {
                                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.SportsEsports, null, tint = CRIMSON, modifier = Modifier.size(30.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(game.label, fontWeight = FontWeight.SemiBold)
                                        Text(game.packageName, color = Color.Gray, fontSize = 10.sp)
                                    }
                                    IconButton(onClick = { launchGame(game.packageName) }) {
                                        Icon(Icons.Default.PlayArrow, "Launch", tint = CRIMSON)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Text("SETTINGS", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text("APP CUSTOMIZATION", color = CRIMSON, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(value = title, onValueChange = { title = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Launcher title") }, singleLine = true)
                    Spacer(Modifier.height(18.dp))
                    Text("GAME SERVER", color = CRIMSON, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(value = ip, onValueChange = { ip = it },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Server IP / hostname") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = port, onValueChange = { port = it.filter(Char::isDigit).take(5) },
                        modifier = Modifier.fillMaxWidth(), label = { Text("Server port") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        if (title.isNotBlank() && ip.isNotBlank() && port.toIntOrNull() in 1..65535) {
                            scope.launch { saveSettings(title.trim(), ip.trim(), port); saved = true }
                        } else saved = false
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = CRIMSON)) {
                        Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("SAVE SETTINGS")
                    }
                    if (saved) Text("Settings saved on this phone.", color = Color(0xFF65D68A))
                    Spacer(Modifier.height(18.dp))
                    Text("GOOGLE LOGIN", color = CRIMSON, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Firebase configuration is required to activate Google sign-in.", color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("APK filename can be changed when building: -PapkName=YourName", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}
