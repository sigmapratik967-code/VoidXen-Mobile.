plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.voidxen.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.voidxen.mobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Override APK filename with: ./gradlew assembleDebug -PapkName=MyLauncher
    applicationVariants.all {
        outputs.all {
            val customName = project.findProperty("apkName")?.toString() ?: "VoidXen_Mobile"
            (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName =
                "${customName}-debug.apk"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.core:core-ktx:1.13.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
