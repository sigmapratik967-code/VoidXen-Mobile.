# VoidXen Mobile v1.0 — phone-only starter

## Included now
- Black + crimson Android launcher UI
- Home, Game Library and Settings tabs
- Detects launchable installed apps and starts them
- Editable launcher title inside the app
- Editable server IP/hostname and port, saved on-device
- APK output filename override through Gradle property

## Important limitations
- Android's installed app label/icon is defined by the APK manifest. The in-app launcher title is editable here; changing the actual installed app label dynamically needs activity-alias implementation or a rebuild.
- The server IP:port is stored and displayed. This starter does not connect to a game server because the game protocol/client is not specified.
- Google sign-in is not active yet. Create a Firebase project, add an Android app with package `com.voidxen.mobile`, download `google-services.json` into `app/`, enable Google provider in Firebase Authentication, and configure the matching SHA-1/SHA-256 signing fingerprints. Then add Firebase Auth dependencies and sign-in UI.
- Installed-app discovery may be restricted by Android/Google Play policy for distributed apps. This starter queries launcher activities; test on your own device and review Android package visibility requirements before publishing.

## Build on Android phone with Termux
1. Install Termux from its official GitHub releases: https://github.com/termux/termux-app/releases
2. Copy/unzip this project into Termux home, for example `~/VoidXenMobile`.
3. Install Java and basic tools:
   ```sh
   pkg update && pkg upgrade
   pkg install openjdk-17 wget unzip git
   ```
4. Install Android SDK command-line tools and platform/build tools compatible with this project's Android Gradle Plugin. Set:
   ```sh
   export ANDROID_HOME=$HOME/android-sdk
   export ANDROID_SDK_ROOT=$ANDROID_HOME
   ```
   The Android SDK must include platform 35 and build-tools 35.0.0. ARM64 Android SDK tool compatibility varies; if aapt2 or Gradle native tools fail on your phone, use a compatible remote build environment.
5. From the project directory:
   ```sh
   gradle assembleDebug
   ```
   Or, if you have a working Gradle wrapper:
   ```sh
   ./gradlew assembleDebug
   ```
6. Output:
   `app/build/outputs/apk/debug/VoidXen_Mobile-debug.apk`

## Change output APK filename
```sh
gradle assembleDebug -PapkName=MyCustomLauncher
```
Output filename becomes `MyCustomLauncher-debug.apk`.

## Change package ID
Edit `applicationId` and `namespace` in `app/build.gradle.kts`, and update the Kotlin package/folder and manifest activity name consistently before release.

## Suggested next steps
- Add Firebase Google sign-in after you create the Firebase project.
- Add app icons and splash screen.
- Add per-game favourites and hide/show controls.
- Add a real game-specific server connect action once you confirm the game/client protocol.
